/* Ember Arc Firebase web configuration.
 * This file uses the Firebase compat SDK loaded in index.html.
 * Web app configuration is safe to include in client-side code; never put service-account keys here.
 */
(function () {
  const firebaseConfig = {
    apiKey: "AIzaSyCH9XoClstAAaQPcXNIzwRepnJX7UeT39A",
    authDomain: "arcstatus-22bdf.firebaseapp.com",
    projectId: "arcstatus-22bdf",
    storageBucket: "arcstatus-22bdf.firebasestorage.app",
    messagingSenderId: "209040839266",
    appId: "1:209040839266:web:8394be44117d28be15373b",
    measurementId: "G-WQCGSZY35Z"
  };

  if (!window.firebase) {
    console.error("Firebase SDK did not load. Check your internet connection and the SDK script tags.");
    return;
  }

  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }
})();
