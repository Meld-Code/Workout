# Ember Arc — Workout platform

A responsive workout tracking website with Firebase Authentication and Cloud Firestore. The interface uses a restrained orange-and-slate design system and Font Awesome icons throughout.

## Included features

- Email/password registration, sign-in, and sign-out through Firebase Authentication.
- Cloud-saved user profile, XP, rank, workout history, challenges, and custom workout library.
- Workout library with category filters and interactive exercise checklists.
- XP levels, rank roadmap, weekly activity summary, and streak display.
- Workout generator with training focus, duration, equipment, and experience preferences.
- Custom challenges with manually tracked progress.
- Profile preferences and account deletion.
- Progress export as a JSON backup.
- Responsive desktop sidebar and mobile navigation.

## Project files

- `index.html` — page structure and Firebase SDK includes.
- `style.css` — responsive application styling.
- `script.js` — UI behavior, workout logic, XP, challenges, and Firebase data access.
- `firebase-config.js` — Firebase web configuration and compat initialization.
- `firestore.rules` — user-owned Firestore document rules.

## Firebase setup

The included `firebase-config.js` is populated with the web app configuration that was present in the uploaded project (`arcstatus-22bdf`). It initializes Firebase using the compat SDK version loaded by `index.html`.

1. In the Firebase Console, open the project configured in `firebase-config.js`.
2. Under **Authentication → Sign-in method**, enable **Email/Password**.
3. Create a **Cloud Firestore** database if one does not already exist.
4. Open **Firestore Database → Rules**, paste in `firestore.rules`, and publish the rules.
5. Under **Authentication → Settings → Authorized domains**, add the domain where you will host Ember Arc.
6. Serve the folder through a local web server for testing, or deploy it with Firebase Hosting. Do not open `index.html` directly as a `file://` URL.

If you use a different Firebase project, replace the values in `firebase-config.js` with that project's web app configuration. Do not put service-account JSON, Admin SDK credentials, or private keys in this folder.

## Data and security notes

Each account stores its main profile document at `users/{uid}`. The included rules restrict reads, writes, and deletes to the authenticated owner of that document and deny access to other collections.

These client-side rules prevent users from accessing other users' profile documents, but they cannot prove that XP or workout completion is legitimate. A user can still modify their own data from browser developer tools. To enforce trusted XP awards and challenge completion, move those operations to a trusted backend such as Firebase Cloud Functions and validate requests server-side.

The Font Awesome stylesheet and Google Font are loaded from CDNs, so an internet connection is required for those assets. Core app layout and behavior remain in the local HTML, CSS, and JavaScript files.

## Notes

- Firebase web configuration is designed to be included in client-side applications. Keep service-account credentials and private keys out of client code.
- Account deletion may require a recent sign-in under Firebase Authentication's security requirements.
- Review Firebase usage and billing limits before opening the app to a large audience.
